    package softwareproj;

public class SoftwareProj {
    public static void main(String[] args) {
        Controller g = new Controller();
        g.setVisible(true);
    }
}