package sms;

import java.io.File;
import java.util.HashMap;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

enum Language {
	ENG
}
public class Translator {
	private static HashMap<String, String> messages;
	private static Language language;
	static {
		messages = new HashMap<String, String>();
		setLanguage(Language.ENG);
	}
	public Translator() {

	}
	public static void getMessagesFromXML() {
		try {
			Vector<String> keys = new Vector<String>();
			Vector<String> values = new Vector<String>();
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document document = builder.parse(new File("Languages.xml"));
			document.getDocumentElement().normalize();
			NodeList keysList = document.getElementsByTagName("key");
			NodeList valuesList = document.getElementsByTagName("val");
			for (int i = 0; i < keysList.getLength(); i++) {
				Node keyNode = keysList.item(i);
				Element keyElement = (Element) keyNode;
				keys.add(keyElement.getAttribute("value"));
			}
                        
			for (int j = 0; j < valuesList.getLength(); j++) {
				Node valueNode = valuesList.item(j);
				Element valueElement = (Element) valueNode;
				if (valueElement.getAttribute("lang").equals(language.toString())) {
					values.add(valueElement.getTextContent());
				}
			}

			for (int i = 0; i < keys.size(); i++)
				messages.put(keys.get(i), values.get(i));

		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
	public static String getValue(final String key) {
		return messages.get(key);
	}
	public static Language getLanguage() {
		return language;
	}
	public static void setLanguage(Language language) {
		Translator.language = language;
	}
        
}
