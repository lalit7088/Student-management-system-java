# Cashier-System
 A simple system which generate orders, prints their invoices, and sends orders to the kitchen screen, built using Java
