package sms;

import java.util.Date;

enum Gender {
	Male, Female
}
public class Student {
	private String name;
	private String surname;
	private int age;
        private Gender gender;
	private String course;
	private Date started;
	private Date graduation;
	int id;
	static int counter;

	static {
		counter = 1;
	}
	public Student() {
		this.id = counter;
		counter++;
	}
	public String getName() {
		return name;
	}
	public void setName(final String name) {
		this.name = name;
	}
	public String getSurname() {
		return surname;
	}
	public void setSurname(final String surname) {
		this.surname = surname;
	}
	public int getAge() {
		return age;
        }
	public void setAge(final int age) {
		this.age = age;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(final String course) {
		this.course = course;
	}
	public int getId() {
		return id;
	}
        public Date getStarted() {
		return started;
	}
	public void setStarted(final Date started) {
		this.started = started;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(final Gender gender) {
		this.gender = gender;
	}
	public Date getGraduation() {
		return graduation;
	}
	public void setGraduation(final Date graduation) {
		this.graduation = graduation;
	}
}
